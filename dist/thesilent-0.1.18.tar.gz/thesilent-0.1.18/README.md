﻿# TheSilent is a subdomain enumeration tool!
# 
# python3 -m TheSilent --host example.com --filename myfilename.txt <optional default None> --dns-only <optional default True>
