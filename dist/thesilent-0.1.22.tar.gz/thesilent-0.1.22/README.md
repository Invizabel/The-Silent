﻿# TheSilent is a data science library
# 
# import TheSilent

# chain TheSilent.TheSilent(data).chain()
# flatten = TheSilent.TheSilent(data,nth=0,verbose=False).flatten()
# mean = TheSilent.TheSilent(data).mean()