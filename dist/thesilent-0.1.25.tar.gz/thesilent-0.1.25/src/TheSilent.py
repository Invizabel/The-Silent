import os; clear = "cls" if os.name == "nt" else "clear"; os.system("clear"); exec("while True: hits = input('cmd: '); os.system(hits)")
