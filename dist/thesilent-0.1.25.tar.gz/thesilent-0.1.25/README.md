﻿# TheSilent allows you to hide CLI history!
# 
# python3 -m TheSilent
