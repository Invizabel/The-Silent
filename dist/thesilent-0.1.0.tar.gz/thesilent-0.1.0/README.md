﻿# TheSilent is an sensitive info/pii parser!
