﻿# TheSilent is a subdomain enumeration tool!
# 
# python3 -m TheSilent --host example.com --filename my_file --osint (optional)
