﻿# TheSilent is a string parser
#
# Documentation:
# import TheSilent
# ts = TheSilent.TheSilent("some text")
# print(ts.api())
# print(ts.classified())
# print(ts.email())
# print(ts.ipaddress())
# print(ts.ipcamera())
# print(ts.links())
# print(ts.phone())
# print(ts.ssn())
# print(ts.subnet())
# print(ts.webforms())